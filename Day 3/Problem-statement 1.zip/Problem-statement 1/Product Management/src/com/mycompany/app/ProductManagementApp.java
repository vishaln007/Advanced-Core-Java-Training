package com.mycompany.app;

import java.util.List;
import java.util.Scanner;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;

public class ProductManagementApp {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		System.out.println("----Welcome To Product Management Application----");
		while(true)
		{
			System.out.println("---Operations---");
			System.out.println("1. Add Product");
			System.out.println("2. Update Product");
			System.out.println("3. Search Product");
			System.out.println("4. Delete Product");
			System.out.println("5. Display All Products");
			System.out.println("6. Exit");
			System.out.println("==================");
			System.out.println("Enter Your Choice");
			System.out.println("==================");
			
			int choice = sc.nextInt();
			
			if(choice == 1)
			{
				System.out.println("==========================================");
				System.out.println("Enter the Product Name you want to add: ");
				System.out.println("==========================================");
				String pname = sc2.nextLine();
				System.out.println("==========================================");
				System.out.println("Enter the Product Price: ");
				System.out.println("==========================================");
				int price = sc.nextInt();
				Product prod = new Product(pname,price);
				ProductManagementDAO.addProduct(prod);
			}
			
			else if(choice == 2)
			{
				System.out.println("=========================================");
				System.out.println("Enter the Product id you want to update: ");
				System.out.println("=========================================");
				int pid = sc.nextInt();
				ProductManagementDAO.updateProduct(pid);
			}
			
			else if(choice == 3)
			{
				System.out.println("===========================================");
				System.out.println("Enter the Product id you are searching for: ");
				System.out.println("===========================================");
				int pid = sc.nextInt();
				ProductManagementDAO.searchProduct(pid);
			}
			
			else if(choice == 4)
			{
				System.out.println("========================================");
				System.out.println("Enter the Product id you want to delete: ");
				System.out.println("========================================");
				int pid = sc.nextInt();
				ProductManagementDAO.deleteProduct(pid);
			}
			
			else if(choice == 5)
			{
				List<Product> products = ProductManagementDAO.getProducts();
				System.out.println();
				System.out.println("--------------------------------------");
				for(int i=0; i<products.size(); i++)
				{
					System.out.println("Product id: "+products.get(i).getId());
					System.out.println("Product Name: "+products.get(i).getName());
					System.out.println("Product Price: "+products.get(i).getPrice());
					System.out.println("--------------------------------------");
				}
				System.out.println();
			}
			
			else if(choice == 6)
			{
				System.out.println("-----Thank You For Using The Application-----");
				break;
			}
			
			else
			{
				System.out.println("Please Enter a Valid Input!!");
				System.out.println();
			}
		}
	}
}
